package main

import "fmt"

func main() {
	type NoKTP string
	var ktpZaki NoKTP = "12313132123"
	fmt.Println(ktpZaki)
	fmt.Println(NoKTP("12313132123"))
}
