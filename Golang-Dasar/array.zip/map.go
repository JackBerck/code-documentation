package main

import "fmt"

func main() {
	person := map[string]string{
		"name":    "John Wick",
		"address": "Mangga Street",
	}
	person["age"] = "27"
	person["title"] = "Mr."
	fmt.Println(person)
	fmt.Println(person["name"])
	fmt.Println(person["address"])
	fmt.Println(person["age"])
	fmt.Println(person["title"])

	book := make(map[string]string)
	book["title"] = "Belajar Golang"
	book["author"] = "John Wick"
	book["ups"] = "Salah"
	delete(book, "ups")
	fmt.Println(book)
}