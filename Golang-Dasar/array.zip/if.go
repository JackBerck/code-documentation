package main

import "fmt"

func main() {
	name := "John"

	if(name == "John") {
		fmt.Println("Hello John")
	} else if (name == "Eko") {
		fmt.Println("Hello Eko")
	} else {
		fmt.Println("You are not John")
	}

	if length := len(name); length > 5 {
		fmt.Println("Terlalu panjang")
	} else {
		fmt.Println("Nama sudah benar")
	}
}