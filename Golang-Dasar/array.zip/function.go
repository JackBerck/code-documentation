package main

import "fmt"

func sayHello() {
	fmt.Println("Hello")
}

func add(a int, b int) int {
	return a + b
}

func multiply(a int, b int) int {
	return a * b
}

func getDetails() (string, int, string) {
	return "John", 25, "New York"
}

func getCompleteName() (firstName, middleName, lastName string, age int) {
	firstName = "John"
	middleName = "Doe"
	lastName = "Smith"
	age = 25
	return
}

func variadicFunction(numbers ...int) int {
	total := 0
	for _, number := range numbers {
		total += number
	}
	return total
}

func getGoodbye(name string) string {
	return "Goodbye " + name
}

type Filter func(string) string

func sayHelloWithFilter(name string, filter Filter) {
	fmt.Println("Hello", filter(name))
}

func filterName(name string) string {
	if name == "Anjing" {
		return "..."
	} else {
		return name
	}
}

type Blacklist func(string) bool

func filterName2(name string, blacklist Blacklist) string {
	if blacklist(name) {
		return "You are blacklisted"
	} else {
		return "Welcome " + name
	}
}

func factorialLoop(value int) int {
	result := 1
	for i := value; i > 0; i-- {
		result *= i
	}
	return result
}

func factorialRecursive(value int) int {
	if value == 1 {
		return 1
	} else {
		return value * factorialRecursive(value-1)
	}
}

func main() {
	sayHello()

	firstName, middleName, lastName, age := getCompleteName()
	fmt.Println("First Name:", firstName)
	fmt.Println("Middle Name:", middleName)
	fmt.Println("Last Name:", lastName)
	fmt.Println("Age:", age)

	fmt.Println(getDetails())

	name, age, _ := getDetails()
	fmt.Println("Name:", name)
	fmt.Println("Age:", age)
	
	result := add(10, 20)
	fmt.Println("Result:", result)

	result = multiply(10, 20)
	fmt.Println("Result:", result)

	result = variadicFunction(10, 20, 30, 40, 50)
	fmt.Println("Result:", result)

	numbers := []int{10, 20, 30, 40, 50}
	result = variadicFunction(numbers...)
	fmt.Println("Result:", result)

	goodbye := getGoodbye
	fmt.Println(goodbye("John"))

	sayHelloWithFilter("John", filterName)
	sayHelloWithFilter("Anjing", filterName)

	blacklist := func(name string) bool {
		return name == "Anjing"
	}
	fmt.Println(filterName2("John", blacklist))

	fmt.Println(filterName2("Anjing", func(name string) bool {
		return name == "Anjing"
	}))

	fmt.Println(factorialLoop(5))
	fmt.Println(factorialRecursive(5))

	counter := 0
	increment := func () {
		fmt.Println("Counter:", counter)
		counter++
	}
	increment()
	increment()

}