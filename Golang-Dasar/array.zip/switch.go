package main

import (
	"fmt"
)

func main() {
	a := 100
	b := 200
	switch {
		case a > b:
			fmt.Println("a is greater than b")
		case a < b:
			fmt.Println("a is less than b")
		default:
			fmt.Println("a is equal to b")
	}

	name := "John"
	switch name {
	case "John":
		fmt.Println("Name is John")
	case "Doe":
		fmt.Println("Name is Doe")
	default:
		fmt.Println("Name is not John or Doe")
	}

	switch length := len(name); length >5 {
	case true:
		fmt.Println("Name is long")
	case false:
		fmt.Println("Name is short")
		default :
		fmt.Println("Name is not John or Doe")
	}
}