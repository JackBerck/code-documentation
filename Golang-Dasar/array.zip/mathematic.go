package main

import "fmt"

func main() {
	var a = 1
	var b = 2

	fmt.Println("a + b = ", a+b)
	fmt.Println("a - b = ", a-b)
	fmt.Println("a * b = ", a*b)
	fmt.Println("a / b = ", a/b)
	fmt.Println("a % b = ", a%b)

	a += a
	fmt.Println("a + a = ", a)

	a--
	fmt.Println("a - 1 = ", a)
}
