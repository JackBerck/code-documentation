package main

import "fmt"

func main() {
	names := [...]string{
		"john",
		"wick",
		"ethan",
		"hunt",
		"eric",
		"jason",
	}

	slice1 := names[1:4]
	fmt.Println(slice1)
	fmt.Println(len(slice1))
	fmt.Println(cap(slice1))

	slice2 := names[:2]
	fmt.Println(slice2)
	fmt.Println(len(slice2))
	fmt.Println(cap(slice2))

	slice3 := names[:]
	fmt.Println(slice3)
	fmt.Println(len(slice3))
	fmt.Println(cap(slice3))

	days := [...]string {"Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"}
	slice4 := days[5:]
	slice4[0] = "Sabtu Lagi"
	slice4[1] = "Minggu Lagi"
	fmt.Println(slice4)
	fmt.Println(days)
	fmt.Println(len(slice4))
	fmt.Println(cap(slice4))

	daySlice := append(slice4)
	fmt.Println(daySlice)
	fmt.Println(days)

	newSlice := make([]string, 2, 5)
	newSlice[0] = "John"
	newSlice[1] = "Wick"
	fmt.Println(newSlice)
	fmt.Println(len(newSlice))
	fmt.Println(cap(newSlice))

	newSlice2 := append(newSlice, "Ethan")
	fmt.Println(newSlice2)

	fromSlice := days[:]
	toSlice := make([]string, len(fromSlice), cap(fromSlice))
	copy(toSlice, fromSlice)
	fmt.Println(toSlice)

	iniArray := [...]int{1, 2, 3, 4, 5}
	iniSlice := []int{1, 2, 3, 4, 5}
	fmt.Println(iniArray)
	fmt.Println(iniSlice)
}