package main

func main() {
	const firstName = "Zaki"
	const lastName = "Dzulfikar"

	// Tidak bisa diubah error
	// firstName := "Tidak bisa diubah"

	const (
		email = "example@gmail.com"
	)
}
