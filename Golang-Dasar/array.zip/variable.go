package main

import "fmt"

func main() {
	var a int
	a = 10
	fmt.Println(a)

	var b int = 20
	fmt.Println(b)

	name := "Muhammad Zaki Dzulfikar"
	name = "Zaki"
	fmt.Println(name)

	var (
		title       = "Go Lang"
		description = "Go Lang Description"
		total       int64
	)
	total = 100
	fmt.Println(title, description, total)
}
