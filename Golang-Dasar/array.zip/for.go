package main

import "fmt"

func main() {
	counter := 0

	for counter <= 10 {
		fmt.Println("Perulangan ke", counter)
		counter++
	}

	fmt.Println("Selesai perulangan")

	for i := 0; i < 5; i++ {
		fmt.Println("Angka", i)
	}

	names := []string{"John", "Wick", "Ethan", "Hunt"}
	for index, name := range names {
		fmt.Println("Index", index, "=", name)
	}
}