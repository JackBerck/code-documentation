package main

import "fmt"

func main() {
	var nilai32 int32 = 123123
	var nilai64 int64 = int64(nilai32)
	var nilai16 int16 = int16(nilai64)
	var pecahan16 float64 = float64(nilai32)
	var name = "Zaki Dzulfikar"
	var z = name[0]
	var zString = string(z)

	fmt.Println("Nilai32 =", nilai32)
	fmt.Println("Nilai64 =", nilai64)
	fmt.Println("Nilai16 =", nilai16)
	fmt.Println("Pecahan16 =", pecahan16)
	fmt.Println("z =", z)
	fmt.Println("z String =", zString)
}
