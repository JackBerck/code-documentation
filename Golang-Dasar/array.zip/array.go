package main

import "fmt"

func main() {
	var zaki = [2]string{"zaki", "mubarok"}

	fmt.Println(zaki[0])
	fmt.Println(zaki[1])
	
	var names = [4]string{
		"john",
		"wick",
		"ethan",
		"hunt",
	}

	fmt.Println(names)
	fmt.Println(names[0])

	var numbers = [...]int{2, 3, 2, 4, 3}

	fmt.Println(numbers)
	fmt.Println(len(numbers))
	fmt.Println(numbers[0])
	
}