package main

import "fmt"

func main() {
	var a = 100
	var b = 200
	var aa1 = "aa"
	var aa2 = "aa"

	var checkNum = a == b
	var checkStr = aa1 == aa2
	fmt.Println(checkNum)
	fmt.Println(checkStr)
}
