package main

import "fmt"

func main() {
	fmt.Println("Hello World")
	fmt.Println("Muhammad Zaki Dzulfikar")
	fmt.Println(len("Muhammad Zaki Dzulfikar"))
	fmt.Println("Hai"[0])
}
