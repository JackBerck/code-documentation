<?php

$server = "localhost";
$user = "root";
$password = "";
$database = "tugas_pertemuan_7";

$koneksi = mysqli_connect($server, $user, $password, $database);
